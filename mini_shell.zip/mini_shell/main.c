#include "header.h"

t_env_copy *environment_copy(char **envp)
{
	int i;
	char *name;
	char *value;
	t_env_copy *original_ptr;
	t_env_copy *ptr;

	i = 0;
	if(!(*envp))
	{
		name = ft_strdup("?");
		value = ft_strdup("0");
		ptr = lstnew(name, value);
		return (ptr);
	}
	name = ft_strdup_name(envp[i]);
	value = ft_strdup_value(envp[i]);
	original_ptr = lstnew(name, value);
	i++;
	while(envp[i])
	{
		name = ft_strdup_name(envp[i]);
		value = ft_strdup_value(envp[i]);
		ptr = lstnew(name, value);
		lstadd_back(&original_ptr, ptr);
		i++;
	}
	name = ft_strdup("?");
	value = ft_strdup("0");
	ptr = lstnew(name, value);
	lstadd_back(&original_ptr, ptr);
	return (original_ptr);
}
void signal_handler()
{
	printf("\n");
	rl_on_new_line();
	rl_replace_line("", 0);
	rl_redisplay();
}

int main(int ac , char **av, char **envp)
{
	char *str;
	t_env_copy *ptr;
	(void)av;
	if (ac != 1)
		return (-1);
	ptr = environment_copy(envp);
	rl_catch_signals=0;
	rl_bind_key('\t', rl_complete);

	signal(SIGINT, signal_handler);
	signal(SIGQUIT, SIG_IGN);
	while(1)
	{
		str = readline("$> ");
		if(!str)
		{
			printf("exit\n");
			exit(ft_atoi(ft_get_env_value("?", ptr)));
		}
		if (!lexer(str, ptr))
			continue ;
		t_tokens *t =tokenizer(str);
		ft_parser(t, ptr);
		add_history(str);
		
	}
	return (0);
}
