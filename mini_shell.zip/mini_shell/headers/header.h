#ifndef BUILTINS_HEADER_H
#define BUILTINS_HEADER_H

#include <errno.h>
#include <stdio.h>
#include <unistd.h>
void pwd(void);


// #include "libft/libft.h"
#include "../utils/utils.h"
#endif