/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exec_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mboutahi <mboutahi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/05 13:08:30 by mboutahi          #+#    #+#             */
/*   Updated: 2025/07/11 21:15:33 by mboutahi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header.h"

char	*find_path(t_env_copy *envp)
{
	while(envp)
	{
		if (ft_strcmp("PATH", envp->name) == 0)
			return (envp->value);
		envp = envp->next;
	}
	return (NULL);
	
}
// void    free_paths(char **strs)
// {
//     int    i;

//     i = 0;
//     while (strs[i])
//     {
//         free(strs[i]);
//         i++;
//     }
//     free(strs);
// }

char	*check_valid_path(char *path, char *cmd)
{
	int		i;
	char	**sub_paths;
	char	*temp;
	char	*command_path;
	struct 	stat checker;
	if (!path)
		return (cmd);
	sub_paths = ft_split(path, ':');
	i = 0;
	while (sub_paths[i])
	{
		temp = ft_strjoin(sub_paths[i], "/");
		command_path =  ft_strjoin(temp, cmd);
		// free(temp);
		if (stat(command_path, &checker) == 0)
		{
			// free(free_paths);
			return (command_path);
		}
		// if (stat(command_path, &checker) == -1)
		// {
		// 	// dprintf(2,"cd: %s %s\n", strerror(errno), command_path); //change to ft_putstr_fd
		// 	update_environment(env, "?", "1");
		// 	exit(1);
		// }
		// if (!S_ISDIR(checker.st_mode))
		// {
		// 	perror("cd:");
		// 	update_environment(env, "?", "1");
		// 	exit(1);
		// }
		// free(command_path), command_path = NULL;
		i++;
	}
	return (cmd);
}

